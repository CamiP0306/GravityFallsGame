<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="inspi 2" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="2550" columns="50">
 <image source="inspi 2.png" width="900" height="928"/>
</tileset>
